package Model;

import java.util.HashSet;
import java.util.Set;

public class Deal {
    public int dealId;
    private final int itemId;
    private int price;
    private int number;
    private final long startTime;
    private long endTime;
    private final long sellerId;
    private DealStatus currentDealStatus;
    private Set<Integer> buyers;
    private enum DealStatus{
        CREATED,
        ACTIVE,
        TERMINATED
    };

    public Deal(int itemId, int price, int number, long endTime, long sellerId, long startTime){
        this.endTime = endTime;
        this.itemId = itemId;
        this.price = price;
        this.number = number;
        this.startTime = startTime;
        this.sellerId = sellerId;
        currentDealStatus = DealStatus.CREATED;
        buyers = new HashSet<>();
    }

    public Deal updateNumOfItems(int number){
        if(number > 0 && currentDealStatus == DealStatus.ACTIVE){
            this.number = number;
        }
        return this;
    }

    public Deal updateEndTime(long endTime){
        if(currentDealStatus != DealStatus.TERMINATED && endTime >0 && endTime > startTime && endTime > System.currentTimeMillis()){
            this.endTime = endTime;
        }
        return this;
    }

    public boolean end(){
        if(currentDealStatus != DealStatus.TERMINATED){
            currentDealStatus = DealStatus.TERMINATED;
            return true;
        }
        return false;
    }

    public boolean claim(int buyerId){
        if(currentDealStatus == DealStatus.ACTIVE && !buyers.contains(buyerId)){
            buyers.add(buyerId);
            this.number--;
            return true;
        }
        return false;
    }
}
