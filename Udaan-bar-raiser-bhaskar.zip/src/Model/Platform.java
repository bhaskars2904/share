package Model;

import java.util.ArrayList;
import java.util.List;

public class Platform {
    public List<Buyer> buyers;
    public List<Seller> sellers;

    private static Platform platform;

    private Platform(){}

    public static Platform getInstance(){
        if(platform == null){
            platform = new Platform();
        }
        return platform;
    }

    public static List<Deal> getAllDeals(){
        List<Deal> deals = new ArrayList<>();
        for(Seller seller : platform.sellers){
            for(Deal deal : seller.getDeals()){
                deals.add(deal);
            }
        }
        return deals;
    }

}

