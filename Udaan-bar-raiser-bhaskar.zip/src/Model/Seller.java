package Model;

import Exceptions.DealNotFoundException;
import Exceptions.InvalidDealException;

import java.util.List;

public class Seller {

    private final int itemId;
    private final int sellerId;
    private List<Deal> deals;

    public Seller(int itemId, int sellerId){
        this.itemId = itemId;
        this.sellerId = sellerId;
    }

    public Deal createDeal(int price, int number, long startTime, long endTime) throws InvalidDealException {

        if(startTime < endTime && price > 0 && number > 0){
            Deal deal = new Deal(this.itemId, price, number, endTime, this.sellerId, startTime);
            deals.add(deal);
            return deal;
        }
        throw new InvalidDealException("Invalid arguments");
    }

    public Deal updateDealItems(int dealId, int number) throws DealNotFoundException{
        for(Deal deal : deals){
            if(deal.dealId == dealId){
                deal.updateNumOfItems(number);
                return deal;
            }
        }
        throw new DealNotFoundException();
    }

    public Deal updateDealEndTime(int dealId, long endTime) throws DealNotFoundException{
        for(Deal deal : deals){
            if(deal.dealId == dealId){
                deal.updateEndTime(endTime);
                return deal;
            }
        }
        throw new DealNotFoundException();
    }

    public boolean endDeal(int dealId) throws DealNotFoundException{
        for(Deal deal : deals){
            if(deal.dealId == dealId){
                return deal.end();
            }
        }
        throw new DealNotFoundException();
    }

    public List<Deal> getDeals() {
        return deals;
    }
}
