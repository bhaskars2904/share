package Model;

import Exceptions.DealNotFoundException;

import java.util.List;

public class Buyer {
    private final int buyerId;

    public Buyer(int buyerId){
        this.buyerId = buyerId;
    }

    public List<Deal> getAvailableDeals(){
        return Platform.getAllDeals();
    }

    public boolean claimDeal(Deal deal) throws DealNotFoundException{
        List<Deal> deals = getAvailableDeals();
        for(Deal availableDeal : deals){
            if(availableDeal.dealId == deal.dealId){
                return availableDeal.claim(buyerId);
            }
        }
        throw new DealNotFoundException();
    }
}
