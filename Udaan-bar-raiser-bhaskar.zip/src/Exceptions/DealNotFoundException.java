package Exceptions;

public class DealNotFoundException extends Exception{
    public DealNotFoundException(){
        super();
    }
}
