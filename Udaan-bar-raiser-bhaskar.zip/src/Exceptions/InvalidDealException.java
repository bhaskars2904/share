package Exceptions;

public class InvalidDealException extends Exception{
    public InvalidDealException(String message){
        super(message);
    }
}
